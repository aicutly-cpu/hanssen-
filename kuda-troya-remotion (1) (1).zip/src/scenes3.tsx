import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {
  Beam, Box, Cal, CCTV, Doc, Dust, Floor, Fog, FBIBuilding, FlatDoc, Glow, Layer, Monitor, Person, Phases, Poly, RED,
  Sky, Skyline, Stage, Tree, W, H, Windows, World, FONT, hash, iso, lin, mix, seg, Flat,
} from './lib';
import {AbsoluteFill} from 'remotion';

// =============== ADEGAN 9 — HARI KETIKA SEMUANYA BERAKHIR ===============
const S9A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const stacks: [number, number, number][] = [[-130, -60, 3], [0, -60, 2], [130, -60, 3], [-130, 40, 2], [0, 40, 3], [130, 40, 2]];
  const t = seg(f, 20, 44);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.2, 1.8]} o={[540, 1000]} tint="rgba(2,16,8,0.25)"
      overlay={
        <AbsoluteFill>
          <svg width={W} height={H}>
            <text x={540} y={520} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={120} fill="#d8f5df" opacity={t} stroke="#03140a" strokeWidth={10} paintOrder="stroke">$50.000</text>
          </svg>
        </AbsoluteFill>
      }>
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#060a0e" /></Layer>
      <Layer depth={1}>
        <World oy={1100}>
          <Floor x={-400} y={-300} w={800} d={600} c="#0a1018" />
          {stacks.map((s, i) => {
            const out: any[] = [];
            for (let k = 0; k < s[2]; k++) {
              out.push(<Box key={'b' + k} x={s[0] - 50} y={s[1]} z={k * 24} w={100} d={52} h={22} c="#2f8f5b" />);
              out.push(<Box key={'r' + k} x={s[0] - 8} y={s[1] - 1} z={k * 24} w={16} d={54} h={24} c="#d8d2b5" />);
            }
            return <g key={i}>{out}</g>;
          })}
        </World>
        <Beam x={540} y={380} w1={60} w2={640} h={800} c="200,255,220" op={0.3} />
      </Layer>
      <Dust f={f} n={24} />
    </Stage>
  );
};
const S9B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.15]} bg="#03050a">
      <Layer depth={0}>
        <Glow x={540} y={900} r={520} c="214,40,57" op={0.14} />
        <Cal x={540} y={900} s={1.6} a="12" b="18" t={seg(f, 14, d - 14)} sa="FEBRUARI 2001" sb="FEBRUARI 2001" />
      </Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
const S9C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const hx = interpolate(p, [0, 0.55], [-330, 10], {extrapolateRight: 'clamp'});
  const placed = p > 0.62;
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.25]} o={[540, 1050]} pan={[[-100, 0], [120, -40]]} tint="rgba(4,18,16,0.25)">
      <Layer depth={0.1}><Sky a="#0a1a22" b="#04080c" /></Layer>
      <Layer depth={0.5}>
        {Array.from({length: 14}).map((_, i) => (
          <polygon key={i} points={`${i * 90 - 60},1000 ${i * 90 + 10},${760 - hash(i) * 120} ${i * 90 + 80},1000`} fill="#071315" />
        ))}
      </Layer>
      <Layer depth={1}>
        <World oy={1060}>
          <Floor x={-700} y={-500} w={1400} d={1000} c="#08161a" grid={90} gc="rgba(120,255,200,0.05)" />
          <Poly p={[iso(-700, -40, 1), iso(700, -40, 1), iso(700, 60, 1), iso(-700, 60, 1)]} fill="#0c2a4a" op={0.9} />
          {[[-300, -300], [-80, -380], [220, -330], [380, -250], [-420, 200], [-200, 280], [300, 260]].map((q, i) => <Tree key={i} x={q[0]} y={q[1]} h={160 + hash(i) * 80} />)}
          <Box x={-160} y={-70} z={0} w={320} d={140} h={16} c="#4a3a2a" />
          <Box x={-160} y={-70} z={16} w={6} d={140} h={46} c="#2a2018" />
          <Box x={154} y={-70} z={16} w={6} d={140} h={46} c="#2a2018" />
          {placed && <Box x={50} y={70} w={30} d={30} h={20} c="#7a6a4a" />}
          <Person x={hx} y={0} z={16} phase={f * 0.28} walking={p < 0.58} s={1.05} />
          {[[-520, 120], [420, 160], [-360, -200], [500, -180]].map((q, i) => (
            <Person key={i} x={q[0]} y={q[1]} s={0.55} coat="#04070b" tie={false} op={seg(p, 0.5, 0.75) * 0.7} />
          ))}
        </World>
      </Layer>
      <Layer depth={1.6}><Fog y={1450} op={0.5} c="60,120,110" /></Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
export const S9 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 3, r: (d: number, fi: number) => <S9A d={d} fi={fi} />}, {w: 2.6, r: (d: number, fi: number) => <S9B d={d} fi={fi} />}, {w: 4.4, r: (d: number, fi: number) => <S9C d={d} fi={fi} />}]} />
);

// =============== ADEGAN 10 — PENANGKAPAN ===============
const S10A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const hx = mix(-30, 200, lin(f, 0, d));
  const hy = mix(10, 150, lin(f, 0, d));
  const ag: [number, number][] = [[-380, -260], [430, -300], [-340, 330], [520, 300]];
  const k = seg(p, 0.35, 1);
  const hp = iso(hx, hy, 0);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.15]} o={[540, 1050]} pan={[[0, 0], [hp[0], hp[1] * 0.6]]} tint="rgba(4,14,20,0.25)">
      <Layer depth={0.1}><Sky a="#0a1a22" b="#04080c" /></Layer>
      <Layer depth={1}>
        <World oy={1060}>
          <Floor x={-700} y={-500} w={1400} d={1000} c="#08161a" grid={90} gc="rgba(120,255,200,0.05)" />
          {[[-300, -300], [220, -330], [380, -250], [-420, 200], [-200, 330], [320, 330]].map((q, i) => <Tree key={i} x={q[0]} y={q[1]} h={160 + hash(i) * 80} />)}
          <Box x={-160} y={-70} w={320} d={140} h={16} c="#4a3a2a" />
          {ag.map((a, i) => (
            <Person key={i} x={mix(a[0], hx + (i % 2 ? 40 : -40), k)} y={mix(a[1], hy + (i < 2 ? -40 : 40), k)} s={1.0} coat="#04070b" tie={false} phase={f * 0.35} walking={k < 1} />
          ))}
          <Person x={hx} y={hy} phase={f * 0.28} walking s={1.05} />
        </World>
      </Layer>
      <Layer depth={1.6}><Fog y={1450} op={0.5} c="60,120,110" /></Layer>
      <Dust f={f} n={22} />
    </Stage>
  );
};
const S10B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const k = seg(f, 0, d * 0.5);
  const flash = Math.max(0, 1 - Math.abs(f - d * 0.5) / 5);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.3, 1.05]} o={[540, 1050]} tint={`rgba(${214},40,57,${0.1 + 0.18 * flash})`} vig={0.9}>
      <Layer depth={0.1}><Sky a="#0a1018" b="#030507" stars={false} /></Layer>
      <Layer depth={1}>
        <World oy={1060}>
          <Floor x={-500} y={-400} w={1000} d={800} c="#08111a" grid={80} />
        </World>
        <Beam x={540} y={320} w1={60} w2={520} h={900} c="214,40,57" op={0.35} />
        <Person at={[mix(200, 400, k), 1160]} s={1.55} coat="#04070b" tie={false} arms="front" />
        <Person at={[mix(880, 680, k), 1160]} s={1.55} coat="#04070b" tie={false} arms="front" flip />
        <Person at={[540, 1170]} s={1.6} arms="front" />
      </Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
const S10C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.2]} o={[540, 1000]} tint="rgba(10,16,30,0.35)" vig={0.95}>
      <Layer depth={0.1}><Sky a="#0a1018" b="#030507" stars={false} /></Layer>
      <Layer depth={1}>
        <World oy={1060}><Floor x={-500} y={-400} w={1000} d={800} c="#08111a" grid={80} /></World>
        <Beam x={540} y={300} w1={70} w2={560} h={940} c="200,220,255" op={0.3} />
        <Person at={[400, 1160]} s={1.55} coat="#04070b" tie={false} arms="front" />
        <Person at={[680, 1160]} s={1.55} coat="#04070b" tie={false} arms="front" flip />
        <Person at={[540, 1170]} s={1.6} arms="front" />
      </Layer>
      <Dust f={f} n={14} />
    </Stage>
  );
};
export const S10 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 4, r: (d: number, fi: number) => <S10A d={d} fi={fi} />}, {w: 2.6, r: (d: number, fi: number) => <S10B d={d} fi={fi} />}, {w: 1.8, r: (d: number, fi: number) => <S10C d={d} fi={fi} />}]} />
);

// =============== ADEGAN 11 — AKHIR SEORANG PENGKHIANAT ===============
const S11A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.3]} o={[540, 1000]} pan={[[-60, 0], [60, -30]]} tint="rgba(8,12,24,0.2)">
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#070b14" /></Layer>
      <Layer depth={1}>
        <World oy={1060}>
          <Floor x={-420} y={-360} w={840} d={760} c="#121a2a" grid={70} />
          <Box x={-420} y={-390} w={840} d={30} h={340} c="#1a2438" />
          <Windows x={-420} y={-390} w={840} d={30} h={340} cols={6} rows={1} face="L" seed={5} lit={0.3} t={f} mx={0.25} />
          <Box x={-180} y={-320} w={360} d={90} h={120} c="#2b2118" />
          <Person x={0} y={-330} z={120} s={0.75} coat="#05070b" tie={false} />
          <Box x={-130} y={-80} w={260} d={80} h={70} c="#2b2118" />
          <Person x={0} y={-20} s={1.0} />
          {[0, 1, 2].map((r) => (
            <g key={r}>
              <Box x={-380} y={120 + r * 70} w={300} d={36} h={46} c="#241b14" />
              <Box x={80} y={120 + r * 70} w={300} d={36} h={46} c="#241b14" />
            </g>
          ))}
        </World>
        {[-1, 1].map((s) => <Beam key={s} x={540 + s * 330} y={420} w1={30} w2={260} h={700} c="255,230,170" op={0.18} rot={s * 12} />)}
        <Beam x={540} y={380} w1={50} w2={360} h={720} op={0.28} />
      </Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
const S11B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.15]} bg="#03050a">
      <Layer depth={0}>
        <Glow x={540} y={900} r={520} c="40,90,170" op={0.2} />
        <Cal x={540} y={900} s={1.6} a="2001" b="2002" t={seg(f, 12, d - 12)} />
      </Layer>
      <Dust f={f} n={24} />
    </Stage>
  );
};
const S11C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const close = seg(f, 10, d * 0.6, Easing.in(Easing.cubic));
  const flash = Math.max(0, 1 - Math.abs(f - d * 0.6) / 4);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.12]} tint={`rgba(255,255,255,${0.12 * flash})`} vig={0.95}>
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#0a0d14" /></Layer>
      <Layer depth={1}>
        <rect x={120} y={380} width={840} height={1250} fill="#10151f" stroke="#1c2433" strokeWidth={10} />
        <rect x={210} y={470} width={660} height={1100} fill="#05070b" />
        {Array.from({length: 9}).map((_, i) => <rect key={i} x={230 + i * 71} y={470} width={14} height={1100} fill="#2a3242" />)}
        {[0, 1, 2].map((i) => <rect key={i} x={210} y={640 + i * 360} width={660} height={14} fill="#2a3242" />)}
        <g transform={`translate(${mix(-740, 0, close)},0)`}>
          <rect x={210} y={470} width={330} height={1100} fill="#0b0f18" opacity={0.0} />
        </g>
        <rect x={210} y={470} width={mix(0, 660, close)} height={1100} fill="#0b0f18" opacity={0.55} />
        <Beam x={540} y={200} w1={60} w2={700} h={1300} c="200,220,255" op={0.18} />
      </Layer>
      <Dust f={f} n={22} />
    </Stage>
  );
};
const S11D = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const t = seg(f, 20, d - 20);
  const gray = seg(f, 10, d - 10);
  return (
    <Stage dur={d} fadeIn={fi} fadeOut={20} zoom={[1.0, 1.35]} o={[540, 1000]} pan={[[0, 0], [0, 20]]} tint={`rgba(40,44,52,${0.5 * gray})`} vig={0.9}
      overlay={<svg width={W} height={H} style={{position: 'absolute'}}><Cal x={540} y={330} s={0.8} a="2002" b="2023" t={t} /></svg>}>
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#06080d" /></Layer>
      <Layer depth={1}>
        <World oy={1100}>
          <Floor x={-900} y={-60} w={1800} d={220} c="#0e1420" grid={90} />
          <Box x={-900} y={-120} w={1800} d={60} h={320} c="#141b2a" />
          <Windows x={-900} y={-120} w={1800} d={60} h={320} cols={12} rows={1} face="L" seed={77} lit={0.0} mx={0.3} off="#06080d" />
          {Array.from({length: 7}).map((_, k) => {
            const c = iso(-760 + k * 260, 30, 0);
            return <ellipse key={k} cx={c[0]} cy={c[1]} rx={120} ry={44} fill="rgba(200,220,255,0.07)" />;
          })}
        </World>
      </Layer>
      <Dust f={f} n={30} />
    </Stage>
  );
};
export const S11 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 3, r: (d: number, fi: number) => <S11A d={d} fi={fi} />}, {w: 1.6, r: (d: number, fi: number) => <S11B d={d} fi={fi} />}, {w: 2.6, r: (d: number, fi: number) => <S11C d={d} fi={fi} />}, {w: 3, r: (d: number, fi: number) => <S11D d={d} fi={fi} />}]} />
);

// =============== ADEGAN 12 — ENDING ===============
const S12A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.3]} o={[540, 1000]} pan={[[0, 0], [30, -20]]} tint="rgba(5,12,30,0.3)" vig={0.85}>
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#05080f" /></Layer>
      <Layer depth={1}>
        <World oy={1060}>
          <Floor x={-420} y={-360} w={840} d={720} c="#0c1220" grid={70} />
          <Box x={-420} y={-390} w={840} d={30} h={340} c="#141d30" />
          {[-300, -120, 60].map((x, i) => <Box key={i} x={x} y={-200} w={140} d={80} h={70} c="#1a2336" />)}
          {[-300, -120, 60].map((x, i) => {
            const c = iso(x + 70, -160, 130);
            return <g key={i}><rect x={c[0] - 60} y={c[1] - 40} width={120} height={80} fill="#05121a" stroke="#1d2a3f" strokeWidth={4} /><rect x={c[0] - 60} y={c[1] - 40} width={120} height={80} fill="rgba(47,230,161,0.04)" /></g>;
          })}
          <Box x={-60} y={40} w={46} d={46} h={20} c="#111826" />
          <Box x={-52} y={48} z={20} w={30} d={30} h={70} c="#111826" />
        </World>
        <Beam x={540} y={300} w1={80} w2={620} h={900} c="150,180,255" op={0.14 + 0.03 * Math.sin(f * 0.2)} />
      </Layer>
      <Dust f={f} n={30} />
    </Stage>
  );
};
const S12B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const k = seg(f, 10, d - 10, Easing.linear);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.4]} o={[540, 1000]} tint="rgba(6,10,22,0.3)">
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#080c14" /></Layer>
      <Layer depth={1}>
        <World oy={1150}><Box x={-300} y={-220} w={600} d={440} h={90} c="#1b2335" /></World>
        <Beam x={540} y={300} w1={60} w2={720} h={950} op={0.32} />
        <Doc x={540} y={960} w={420} h={560} lines={14} prog={1} stamp />
        {Array.from({length: 5}).map((_, i) => (
          <rect key={i} x={380} y={800 + i * 78} width={mix(0, 300, Math.max(0, Math.min(1, k * 5 - i)))} height={12} fill={RED} opacity={0.7} />
        ))}
      </Layer>
      <Dust f={f} n={24} />
    </Stage>
  );
};
const S12C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} fadeOut={36} zoom={[2.1, 0.95]} o={[453, 750]} pan={[[-41, -100], [0, 40]]} tint="rgba(4,10,26,0.3)" vig={0.9}>
      <Layer depth={0.1}><Sky /></Layer>
      <Layer depth={0.3}><Skyline y={1180} c="#0a1426" seed={2} f={f} /></Layer>
      <Layer depth={0.6}><Skyline y={1280} c="#0c1a30" seed={9} f={f} sc={1.3} /></Layer>
      <Layer depth={1}>
        <World>
          <Floor x={-520} y={-420} w={1000} d={900} c="#0b1220" grid={70} />
          <FBIBuilding t={f} />
        </World>
      </Layer>
      <Layer depth={1.6}><Fog y={1450} op={0.6} /></Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
export const S12 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 2.2, r: (d: number, fi: number) => <S12A d={d} fi={fi} />}, {w: 2.2, r: (d: number, fi: number) => <S12B d={d} fi={fi} />}, {w: 5.6, r: (d: number, fi: number) => <S12C d={d} fi={fi} />}]} />
);
