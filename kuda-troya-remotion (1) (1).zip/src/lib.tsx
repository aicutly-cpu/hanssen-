import React, {createContext, useContext, useId} from 'react';
import {AbsoluteFill, Easing, Sequence, interpolate, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';

export const FONT = loadFont('normal', {weights: ['800', '900'], subsets: ['latin']}).fontFamily;
export const W = 1080;
export const H = 1920;
export const RED = '#d62839';

// ---------- util ----------
export const iso = (x: number, y: number, z: number = 0): [number, number] => [(x - y) * 0.866, (x + y) * 0.5 - z];
export const hash = (n: number) => {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};
const EASE = Easing.inOut(Easing.cubic);
export const seg = (f: number, a: number, b: number, e: any = EASE) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: e});
export const lin = (f: number, a: number, b: number) => seg(f, a, b, Easing.linear);
export const mix = (a: number, b: number, t: number) => a + (b - a) * t;
export const useUid = () => 'u' + useId().replace(/[^a-zA-Z0-9]/g, '');
export const shade = (hex: string, k: number) => {
  const n = parseInt(hex.slice(1), 16);
  const c = (v: number) => Math.max(0, Math.min(255, Math.round(v * k)));
  return `rgb(${c((n >> 16) & 255)},${c((n >> 8) & 255)},${c(n & 255)})`;
};
const pts = (a: [number, number][]) => a.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
export const Poly = ({p, fill, op = 1, stroke, sw = 1}: any) => (
  <polygon points={pts(p)} fill={fill} opacity={op} stroke={stroke} strokeWidth={sw} />
);

// ---------- kamera / panggung ----------
const CamCtx = createContext({px: 0, py: 0});

export const Stage = ({
  dur, fadeIn = 0, fadeOut = 0, zoom = [1, 1.12], pan = [[0, 0], [0, 0]], o = [540, 960],
  bg = '#060a12', tint = 'rgba(0,0,0,0)', vig = 0.75, overlay = null, children,
}: any) => {
  const f = useCurrentFrame();
  const p = Math.max(0, Math.min(1, f / Math.max(1, dur)));
  const e = Easing.inOut(Easing.sin);
  const z = interpolate(p, [0, 1], zoom, {easing: e});
  const px = interpolate(p, [0, 1], [pan[0][0], pan[1][0]], {easing: e});
  const py = interpolate(p, [0, 1], [pan[0][1], pan[1][1]], {easing: e});
  const op = (fadeIn ? lin(f, 0, fadeIn) : 1) * (fadeOut ? 1 - lin(f, dur - fadeOut, dur) : 1);
  return (
    <AbsoluteFill style={{background: bg, opacity: op, overflow: 'hidden'}}>
      <CamCtx.Provider value={{px, py}}>
        <AbsoluteFill style={{transform: `scale(${z})`, transformOrigin: `${o[0]}px ${o[1]}px`}}>{children}</AbsoluteFill>
      </CamCtx.Provider>
      <AbsoluteFill style={{background: tint}} />
      <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 46%, rgba(0,0,0,0) 38%, rgba(0,0,0,${vig}) 100%)`}} />
      <AbsoluteFill
        style={{
          background: 'repeating-linear-gradient(0deg, rgba(255,255,255,0.025) 0px, rgba(255,255,255,0.025) 1px, rgba(0,0,0,0) 3px)',
        }}
      />
      {overlay}
    </AbsoluteFill>
  );
};

export const Layer = ({depth = 1, children}: any) => {
  const {px, py} = useContext(CamCtx);
  return (
    <AbsoluteFill style={{transform: `translate(${-px * depth}px,${-py * depth}px)`}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{overflow: 'visible'}}>
        {children}
      </svg>
    </AbsoluteFill>
  );
};
export const World = ({ox = 540, oy = 1000, children}: any) => <g transform={`translate(${ox},${oy})`}>{children}</g>;

// Beberapa fase dalam satu adegan, tiap fase punya kamera sendiri
export const Phases = ({dur, parts, firstFade = 0, ov = 8}: any) => {
  const tot = parts.reduce((a: number, p: any) => a + p.w, 0);
  let acc = 0;
  return (
    <>
      {parts.map((pt: any, i: number) => {
        const s = Math.round((acc / tot) * dur);
        acc += pt.w;
        const e = Math.round((acc / tot) * dur);
        const from = i ? s - ov : 0;
        const d = e - from;
        return (
          <Sequence key={i} from={from} durationInFrames={d}>
            {pt.r(d, i ? ov : firstFade)}
          </Sequence>
        );
      })}
    </>
  );
};

// ---------- latar ----------
export const Sky = ({a = '#0a1530', b = '#04060c', stars = true}: any) => {
  const id = useUid();
  return (
    <g>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={a} />
          <stop offset="1" stopColor={b} />
        </linearGradient>
      </defs>
      <rect x={-400} y={-400} width={W + 800} height={H + 800} fill={`url(#${id})`} />
      {stars &&
        Array.from({length: 50}).map((_, i) => (
          <circle key={i} cx={hash(i) * W} cy={hash(i + 99) * 900} r={1 + hash(i + 5) * 1.6} fill="#fff" opacity={0.25 + hash(i + 7) * 0.5} />
        ))}
    </g>
  );
};
export const Skyline = ({y = 1200, c = '#0a1426', seed = 1, f = 0, sc = 1}: any) => (
  <g>
    {Array.from({length: 18}).map((_, i) => {
      const w = 60 + hash(seed + i) * 50;
      const h = (110 + hash(seed + i * 3) * 280) * sc;
      const x = i * 80 - 150;
      return (
        <g key={i}>
          <rect x={x} y={y - h} width={w} height={h + 800} fill={c} />
          {[0, 1, 2].map((k) => (
            <rect key={k} x={x + 10 + k * 16} y={y - h + 20 + hash(seed + i + k) * (h - 40)} width={7} height={10} fill="#ffd48a" opacity={hash(seed + i * 5 + k) > 0.55 ? 0.5 + 0.2 * Math.sin(f * 0.1 + i) : 0} />
          ))}
        </g>
      );
    })}
  </g>
);
export const Fog = ({y = 1400, op = 0.5, c = '120,150,200'}: any) => {
  const id = useUid();
  return (
    <g>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={`rgba(${c},0)`} />
          <stop offset="1" stopColor={`rgba(${c},${op})`} />
        </linearGradient>
      </defs>
      <rect x={-300} y={y} width={W + 600} height={H - y + 400} fill={`url(#${id})`} />
    </g>
  );
};
export const Glow = ({x, y, r = 200, c = '255,207,122', op = 0.5}: any) => {
  const id = useUid();
  return (
    <g>
      <defs>
        <radialGradient id={id}>
          <stop offset="0" stopColor={`rgba(${c},${op})`} />
          <stop offset="1" stopColor={`rgba(${c},0)`} />
        </radialGradient>
      </defs>
      <circle cx={x} cy={y} r={r} fill={`url(#${id})`} />
    </g>
  );
};
export const Beam = ({x, y, w1 = 20, w2 = 220, h = 600, c = '255,207,122', op = 0.35, rot = 0}: any) => {
  const id = useUid();
  return (
    <g transform={`translate(${x},${y}) rotate(${rot})`}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={`rgba(${c},${op})`} />
          <stop offset="1" stopColor={`rgba(${c},0)`} />
        </linearGradient>
      </defs>
      <polygon points={`${-w1 / 2},0 ${w1 / 2},0 ${w2 / 2},${h} ${-w2 / 2},${h}`} fill={`url(#${id})`} />
    </g>
  );
};
export const Dust = ({f, n = 30}: any) => (
  <AbsoluteFill>
    <svg width={W} height={H}>
      {Array.from({length: n}).map((_, i) => {
        const x = (hash(i) * W + Math.sin(f * 0.02 + i) * 40 + f * (0.2 + hash(i + 3) * 0.4)) % W;
        const y = (hash(i + 50) * H - f * (0.3 + hash(i + 9) * 0.6) + H * 4) % H;
        return <circle key={i} cx={x} cy={y} r={1 + hash(i + 8) * 2.2} fill="#cfe0ff" opacity={0.12 + hash(i + 2) * 0.25} />;
      })}
    </svg>
  </AbsoluteFill>
);

// ---------- isometrik ----------
export const Floor = ({x, y, w, d, z = 0, c = '#101826', grid = 0, gc = 'rgba(255,255,255,0.06)'}: any) => {
  const lines: any[] = [];
  if (grid) {
    for (let i = grid; i < w; i += grid) {
      const a = iso(x + i, y, z), b = iso(x + i, y + d, z);
      lines.push(<line key={'a' + i} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={gc} strokeWidth={1.5} />);
    }
    for (let i = grid; i < d; i += grid) {
      const a = iso(x, y + i, z), b = iso(x + w, y + i, z);
      lines.push(<line key={'b' + i} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={gc} strokeWidth={1.5} />);
    }
  }
  return (
    <g>
      <Poly p={[iso(x, y, z), iso(x + w, y, z), iso(x + w, y + d, z), iso(x, y + d, z)]} fill={c} />
      {lines}
    </g>
  );
};
export const Box = ({x, y, z = 0, w, d, h, c = '#2a3446'}: any) => {
  const P = iso;
  return (
    <g>
      <Poly p={[P(x, y + d, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x, y + d, z + h)]} fill={shade(c, 0.78)} />
      <Poly p={[P(x + w, y, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x + w, y, z + h)]} fill={shade(c, 0.5)} />
      <Poly p={[P(x, y, z + h), P(x + w, y, z + h), P(x + w, y + d, z + h), P(x, y + d, z + h)]} fill={shade(c, 1.18)} />
    </g>
  );
};
export const Windows = ({x, y, z = 0, w, d, h, cols, rows, face = 'L', seed = 1, lit = 0.35, t = 0, on = '#ffd48a', off = '#0b1424', mx = 0.18}: any) => {
  const out: any[] = [];
  const L = face === 'L' ? w : d;
  const cw = L / cols, rh = h / rows;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      const a = i * cw + cw * mx, ww = cw * (1 - 2 * mx), b = z + j * rh + rh * 0.25, wh = rh * 0.5;
      const isOn = hash(seed + i * 13 + j * 7) < lit;
      const pp: [number, number][] =
        face === 'L'
          ? [iso(x + a, y + d, b), iso(x + a + ww, y + d, b), iso(x + a + ww, y + d, b + wh), iso(x + a, y + d, b + wh)]
          : [iso(x + w, y + a, b), iso(x + w, y + a + ww, b), iso(x + w, y + a + ww, b + wh), iso(x + w, y + a, b + wh)];
      out.push(<Poly key={i + '-' + j} p={pp} fill={isOn ? on : off} op={isOn ? 0.75 + 0.25 * Math.sin(t * 0.08 + i * 3 + j) : 0.9} />);
    }
  }
  return <g>{out}</g>;
};
export const Flat = ({x, y, z = 0, rot = 0, children}: any) => {
  const [px, py] = iso(x, y, z);
  return <g transform={`translate(${px},${py}) matrix(0.866,0.5,-0.866,0.5,0,0) rotate(${rot})`}>{children}</g>;
};
export const Tree = ({x, y, z = 0, h = 170, c = '#0f2a2a', s = 1}: any) => {
  const [px, py] = iso(x, y, z);
  return (
    <g transform={`translate(${px},${py})`}>
      <ellipse cx={0} cy={2} rx={46 * s} ry={14 * s} fill="#000" opacity={0.35} />
      <rect x={-7} y={-h * 0.35} width={14} height={h * 0.35} fill="#2a1d18" />
      {[0, 1, 2].map((i) => (
        <polygon key={i} points={`${-56 * s + i * 12},${-h * 0.3 - i * h * 0.22} ${56 * s - i * 12},${-h * 0.3 - i * h * 0.22} 0,${-h * 0.75 - i * h * 0.22}`} fill={shade(c, 0.9 + i * 0.15)} />
      ))}
    </g>
  );
};

// ---------- karakter faceless ----------
export const Person = ({x = 0, y = 0, z = 0, at, s = 1, phase = 0, walking = false, coat = '#10151f', flip = false, arms = 'down', tie = true, op = 1}: any) => {
  const [px, py] = at || iso(x, y, z);
  const sw = walking ? Math.sin(phase) * 14 : 0;
  const bob = walking ? -Math.abs(Math.sin(phase)) * 4 : 0;
  const A: any = {
    down: [[-20, -125, -25, -72], [20, -125, 25, -72]],
    up: [[-20, -128, -36, -190], [20, -128, 36, -190]],
    front: [[-20, -125, -6, -92], [20, -125, 6, -92]],
  };
  const a = A[arms];
  return (
    <g transform={`translate(${px},${py + bob}) scale(${flip ? -s : s},${s})`} opacity={op}>
      <ellipse cx={0} cy={2} rx={36} ry={10} fill="#000" opacity={0.4} />
      <rect x={-15 + sw * 0.6} y={-64} width={12} height={64} rx={5} fill={shade(coat, 0.7)} />
      <rect x={3 - sw * 0.6} y={-64} width={12} height={64} rx={5} fill={shade(coat, 0.7)} />
      <path d="M-24,-62 L-19,-132 Q0,-146 19,-132 L24,-62 Z" fill={coat} />
      <line x1={a[0][0]} y1={a[0][1]} x2={a[0][2]} y2={a[0][3]} stroke={shade(coat, 0.9)} strokeWidth={12} strokeLinecap="round" />
      <line x1={a[1][0]} y1={a[1][1]} x2={a[1][2]} y2={a[1][3]} stroke={shade(coat, 0.9)} strokeWidth={12} strokeLinecap="round" />
      {tie && <rect x={-3} y={-132} width={6} height={36} fill={RED} opacity={0.85} />}
      <rect x={-6} y={-150} width={12} height={12} fill="#3a4252" />
      <circle cx={0} cy={-164} r={18} fill="#566074" />
      <ellipse cx={-5} cy={-170} rx={8} ry={6} fill="#fff" opacity={0.08} />
    </g>
  );
};
export const Hand = ({x, y, rot = 0, s = 1}: any) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <rect x={40} y={-18} width={200} height={46} rx={14} fill="#10151f" />
    <path d="M0,0 Q40,-30 90,-12 L96,6 Q50,26 0,22 Z" fill="#4a5568" />
    <path d="M90,-12 l28,-4 l4,10 l-26,10 z" fill="#566176" />
  </g>
);

// ---------- objek ----------
export const Doc = ({x, y, w = 160, h = 210, rot = 0, c = '#d9dde5', lines = 7, stamp = false, s = 1, op = 1, prog = 1}: any) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`} opacity={op}>
    <rect x={-w / 2 + 6} y={-h / 2 + 8} width={w} height={h} rx={4} fill="#000" opacity={0.3} />
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={4} fill={c} />
    {Array.from({length: lines}).map((_, i) => {
      const full = (w - 32) * (0.55 + 0.45 * hash(i + 4));
      const k = Math.max(0, Math.min(1, prog * lines - i));
      return <rect key={i} x={-w / 2 + 16} y={-h / 2 + 24 + (i * (h - 56)) / lines} width={full * k} height={6} fill="#7d8798" />;
    })}
    {stamp && <rect x={w / 2 - 70} y={-h / 2 + 12} width={54} height={16} fill={RED} opacity={0.9} />}
  </g>
);
export const FlatDoc = ({x, y, z = 0, w = 120, d = 160, c = '#d9dde5', rot = 0, stamp = false, lines = 6}: any) => (
  <Flat x={x} y={y} z={z} rot={rot}>
    <rect width={w} height={d} fill={c} />
    {Array.from({length: lines}).map((_, i) => (
      <rect key={i} x={10} y={14 + i * ((d - 30) / lines)} width={(w - 20) * (0.5 + 0.5 * hash(i + 2))} height={5} fill="#7d8798" />
    ))}
    {stamp && <rect x={w - 44} y={8} width={34} height={12} fill={RED} />}
  </Flat>
);
export const Envelope = ({x, y, s = 1, rot = 0, open = 0, seal = false}: any) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-104} y={-70} width={220} height={150} rx={6} fill="#000" opacity={0.3} />
    <rect x={-110} y={-75} width={220} height={150} rx={6} fill="#cdbd94" />
    <polygon points="-110,75 0,0 110,75" fill="#b6a679" />
    <g transform={`translate(0,-75) scale(1,${1 - 2 * open}) translate(0,75)`}>
      <polygon points="-110,-75 110,-75 0,0" fill={open > 0.5 ? '#a49468' : '#bfae80'} />
    </g>
    {seal && <circle cx={0} cy={0} r={14} fill={RED} />}
  </g>
);
export const Cal = ({x, y, s = 1, a, b, t = 0, sa = '', sb = ''}: any) => {
  const showB = t >= 0.5;
  const sy = Math.max(0.03, showB ? (t - 0.5) * 2 : 1 - t * 2);
  const label = showB ? b : a;
  const sub = showB ? sb : sa;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <g transform={`scale(1,${sy})`}>
        <rect x={-176} y={-146} width={352} height={310} rx={20} fill="#000" opacity={0.35} />
        <rect x={-170} y={-150} width={340} height={300} rx={20} fill="#e8eaee" />
        <path d="M-170,-130 Q-170,-150 -150,-150 L150,-150 Q170,-150 170,-130 L170,-76 L-170,-76 Z" fill="#c4232f" />
        {[-100, 0, 100].map((cx) => (
          <rect key={cx} x={cx - 6} y={-166} width={12} height={36} rx={6} fill="#2a3040" />
        ))}
        <text x={0} y={52} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={label.length > 4 ? 100 : 120} fill="#10151f">
          {label}
        </text>
        <text x={0} y={118} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={34} fill="#5a6475" letterSpacing={4}>
          {sub}
        </text>
      </g>
    </g>
  );
};
export const Monitor = ({x, y, s = 1, t = 0, mode = 'code', tint = '#2fe6a1', children}: any) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x={-20} y={110} width={40} height={50} fill="#151b27" />
    <rect x={-70} y={150} width={140} height={14} rx={6} fill="#151b27" />
    <rect x={-170} y={-120} width={340} height={240} rx={14} fill="#0b0f17" stroke="#2a3447" strokeWidth={3} />
    <rect x={-156} y={-106} width={312} height={212} rx={6} fill="#05121a" />
    {children}
    {mode === 'code' &&
      Array.from({length: 11}).map((_, i) => {
        const rowH = 19;
        const k = Math.floor((t * 0.8) / rowH);
        const off = (t * 0.8) % rowH;
        const hex = Array.from({length: 6}).map((_, q) => Math.floor(hash(k + i + q * 7) * 65535).toString(16).padStart(4, '0')).join(' ');
        return (
          <text key={i} x={-148} y={-90 + i * rowH - off} fontFamily="monospace" fontSize={13} fill={tint} opacity={0.75}>
            {hex}
          </text>
        );
      })}
    <rect x={-156} y={-106} width={312} height={212} rx={6} fill="rgba(47,230,161,0.05)" />
  </g>
);
export const Flag = ({x, y, w = 220, h = 140, kind = 'us', f = 0, op = 0.55}: any) => {
  const sk = Math.sin(f * 0.07) * 4;
  return (
    <g opacity={op} transform={`translate(${x},${y})`}>
      <rect x={-6} y={-10} width={8} height={h + 200} fill="#1a2233" />
      <g transform={`skewY(${sk})`}>
        {kind === 'us' ? (
          <>
            {Array.from({length: 7}).map((_, i) => (
              <rect key={i} x={0} y={i * (h / 7)} width={w} height={h / 7} fill={i % 2 ? '#c9ced8' : '#8d1f2c'} />
            ))}
            <rect x={0} y={0} width={w * 0.45} height={h * 0.55} fill="#1c3566" />
            {Array.from({length: 9}).map((_, i) => (
              <circle key={i} cx={14 + (i % 3) * 34} cy={14 + Math.floor(i / 3) * 24} r={3} fill="#e6e9f0" />
            ))}
          </>
        ) : (
          <>
            <rect x={0} y={0} width={w} height={h} fill="#8d1f2c" />
            <circle cx={w * 0.22} cy={h * 0.3} r={16} fill="#e0b84c" />
          </>
        )}
      </g>
    </g>
  );
};
export const CCTV = ({x, y, s = 1, f = 0, rot = 0}: any) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-8} y={-30} width={16} height={34} fill="#1a2233" />
    <rect x={-60} y={-12} width={100} height={36} rx={8} fill="#2b3446" />
    <rect x={30} y={-6} width={24} height={24} rx={4} fill="#0b0f17" />
    <circle cx={-44} cy={-2} r={5} fill={RED} opacity={Math.sin(f * 0.2) > 0 ? 1 : 0.2} />
  </g>
);
export const Photo = ({x, y, rot = 0, s = 1, hot = false}: any) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-70} y={-86} width={146} height={176} fill="#000" opacity={0.3} />
    <rect x={-75} y={-90} width={150} height={180} fill="#d8dce3" />
    <rect x={-62} y={-77} width={124} height={124} fill="#1a2231" />
    <circle cx={0} cy={-32} r={22} fill="#5b6577" />
    <path d="M-44,47 Q-40,0 0,-6 Q40,0 44,47 Z" fill="#4a5466" />
    {hot && (
      <>
        <line x1={-62} y1={-77} x2={62} y2={47} stroke={RED} strokeWidth={6} />
        <line x1={62} y1={-77} x2={-62} y2={47} stroke={RED} strokeWidth={6} />
      </>
    )}
    <circle cx={0} cy={-92} r={7} fill={RED} />
  </g>
);
export const Pawn = ({x, y, z = 16, c, king = false, f = 0}: any) => {
  const [px, py] = iso(x, y, z);
  const k = king ? 1.7 : 1;
  return (
    <g transform={`translate(${px},${py}) scale(${k})`}>
      <ellipse cx={0} cy={2} rx={24} ry={8} fill="#000" opacity={0.4} />
      <path d="M-18,0 Q-14,-30 -6,-46 L6,-46 Q14,-30 18,0 Z" fill={c} />
      <circle cx={0} cy={-60} r={14} fill={shade(c, 1.15)} />
      {king && <rect x={-3} y={-92} width={6} height={22} fill={shade(c, 1.2)} />}
      {king && <rect x={-10} y={-84} width={20} height={6} fill={shade(c, 1.2)} />}
      <ellipse cx={-5} cy={-64} rx={5} ry={4} fill="#fff" opacity={0.18} />
    </g>
  );
};
export const Lower = ({text, sub, y = 1240, from = 20}: any) => {
  const f = useCurrentFrame();
  const t = seg(f, from, from + 18);
  return (
    <AbsoluteFill>
      <svg width={W} height={H}>
        <g opacity={t} transform={`translate(${(1 - t) * -40},0)`}>
          <rect x={90} y={y - 52} width={6} height={sub ? 108 : 70} fill={RED} />
          <text x={116} y={y} fontFamily={FONT} fontWeight={900} fontSize={54} fill="#fff" letterSpacing={3}>
            {text}
          </text>
          {sub && (
            <text x={116} y={y + 46} fontFamily={FONT} fontWeight={800} fontSize={30} fill="#9fb0cc" letterSpacing={3}>
              {sub}
            </text>
          )}
        </g>
      </svg>
    </AbsoluteFill>
  );
};

// ---------- gedung FBI (dipakai ulang) ----------
export const FBIBuilding = ({t = 0, hi = true, seed = 3}: any) => {
  const hx = iso(0, 100, 300);
  return (
    <g>
      <Box x={-190} y={-140} w={380} d={280} h={120} c="#24304a" />
      <Windows x={-190} y={-140} w={380} d={280} h={120} cols={8} rows={2} face="L" seed={seed} lit={0.3} t={t} />
      <Windows x={-190} y={-140} w={380} d={280} h={120} cols={6} rows={2} face="R" seed={seed + 4} lit={0.3} t={t} />
      <Box x={-130} y={-100} z={120} w={260} d={200} h={400} c="#2a3752" />
      <Windows x={-130} y={-100} z={120} w={260} d={200} h={400} cols={6} rows={8} face="L" seed={seed + 1} lit={0.28} t={t} />
      <Windows x={-130} y={-100} z={120} w={260} d={200} h={400} cols={5} rows={8} face="R" seed={seed + 2} lit={0.28} t={t} />
      <rect x={iso(0, 0, 520)[0] - 3} y={iso(0, 0, 520)[1] - 80} width={6} height={80} fill="#1a2233" />
      <circle cx={iso(0, 0, 520)[0]} cy={iso(0, 0, 520)[1] - 84} r={6} fill={RED} opacity={Math.sin(t * 0.15) > 0 ? 1 : 0.25} />
      {hi && (
        <g>
          <Glow x={hx[0]} y={hx[1] + 10} r={130} op={0.35} />
          <Poly p={[iso(-20, 100, 270), iso(20, 100, 270), iso(20, 100, 330), iso(-20, 100, 330)]} fill="#ffd98a" />
          <Person at={[hx[0], hx[1] + 30]} s={0.3} coat="#05070b" tie={false} />
        </g>
      )}
    </g>
  );
};
