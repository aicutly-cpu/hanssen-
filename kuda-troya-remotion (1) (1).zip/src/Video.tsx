import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useVideoConfig} from 'remotion';
import SCRIPT from './script.json';
import {S1, S2, S3, S4} from './scenes1';
import {S5, S6, S7, S8} from './scenes2';
import {S9, S10, S11, S12} from './scenes3';
import {Subtitles} from './Subtitles';

export const LEAD = 0.6; // detik jeda sebelum narasi mulai
export const TAIL = 2.4; // detik penutup setelah narasi selesai
const XF = 10; // frame crossfade antaradegan
const COMPS = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12];

export const sceneBounds = (voDur: number, timing: any): number[] => {
  const n = SCRIPT.length;
  if (timing?.scenes?.length === n) return [...timing.scenes.map((s: any) => s.start), voDur];
  const w = SCRIPT.map((s) => s.text.length + (s.text.match(/[.!?]/g) || []).length * 6);
  const tot = w.reduce((a, b) => a + b, 0);
  let acc = 0;
  const b = [0];
  w.forEach((x) => {
    acc += x;
    b.push((acc / tot) * voDur);
  });
  return b;
};

export const Video = ({voDur, timing, voMissing}: any) => {
  const {fps, durationInFrames} = useVideoConfig();
  const b = sceneBounds(voDur, timing);
  const fr = b.map((s) => Math.round((LEAD + s) * fps));
  fr[0] = 0;
  fr[fr.length - 1] = durationInFrames;
  const subs = SCRIPT.map((s, i) => ({
    from: i === 0 ? Math.round(LEAD * fps) : fr[i],
    to: i === SCRIPT.length - 1 ? Math.round((LEAD + voDur) * fps) : fr[i + 1],
    text: s.text,
  }));
  const climaxFrom = fr[9], climaxTo = fr[10];
  const bgmVol = (f: number) => {
    const fin = Math.min(1, f / 45);
    const fout = Math.min(1, (durationInFrames - f) / (fps * 3));
    const boost = f > climaxFrom && f < climaxTo ? 1.6 : 1;
    return 0.13 * Math.max(0, Math.min(fin, fout)) * boost;
  };
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {COMPS.map((C: any, i: number) => {
        const from = i ? fr[i] - XF : 0;
        return (
          <Sequence key={i} from={from} durationInFrames={fr[i + 1] - from}>
            <C dur={fr[i + 1] - from} />
          </Sequence>
        );
      })}
      <Subtitles scenes={subs} />
      {!voMissing && (
        <Sequence from={Math.round(LEAD * fps)}>
          <Audio src={staticFile('vo.mp3')} volume={1} />
        </Sequence>
      )}
      <Audio src={staticFile('bgm.mp3')} loop volume={bgmVol} />
    </AbsoluteFill>
  );
};
