import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {
  Beam, Box, Cal, CCTV, Doc, Dust, Envelope, Flag, Floor, Fog, FBIBuilding, FlatDoc, Glow, Hand, Layer, Lower,
  Monitor, Person, Phases, Photo, Poly, RED, Skyline, Sky, Stage, Tree, W, H, Windows, World, hash, iso, lin, mix, seg,
} from './lib';

// =============== ADEGAN 5 — MONTASE KEBOCORAN ===============
const BG = () => <Layer depth={0.2}><Sky stars={false} a="#0a1222" b="#04060c" /></Layer>;

const M1 = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f, fps, config: {damping: 13}});
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.1, 1.45]} tint="rgba(8,14,30,0.2)">
      <BG />
      <Layer depth={1}>
        <World oy={1150}><Floor x={-400} y={-300} w={800} d={600} c="#0c1322" grid={60} /><Box x={-260} y={-140} w={520} d={280} h={90} c="#232d40" /></World>
        <Beam x={540} y={380} w1={60} w2={640} h={800} op={0.35} />
        {[-1, 0, 1].map((i) => (
          <Doc key={i} x={540 + i * 150} y={mix(1300, 980, s)} rot={i * 14 * s} w={210} h={280} stamp={i === 0} lines={8} />
        ))}
      </Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
const M2 = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const blob = (pp: number[][], fill: string) => <Poly p={pp.map((q) => iso(q[0], q[1], 3))} fill={fill} />;
  const a = iso(-150, -20, 4), b = iso(160, 10, 4);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.5]} o={[540, 1000]} pan={[[-60, 0], [60, 0]]} tint="rgba(8,16,34,0.2)">
      <BG />
      <Layer depth={1}>
        <World oy={1050}>
          <Floor x={-340} y={-240} w={680} d={480} c="#0e2236" grid={40} gc="rgba(120,170,255,0.12)" />
          {blob([[-300, -100], [-170, -190], [-40, -110], [-80, 50], [-210, 100], [-310, 10]], '#1d3b5c')}
          {blob([[40, -140], [200, -200], [320, -90], [280, 70], [120, 110], [20, 0]], '#3a1f26')}
          <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={RED} strokeWidth={4} strokeDasharray="12 10" strokeDashoffset={-f * 2} />
          {[a, b].map((q, i) => (
            <g key={i}>
              <Glow x={q[0]} y={q[1]} r={60 + 18 * Math.sin(f * 0.2 + i)} c="214,40,57" op={0.6} />
              <circle cx={q[0]} cy={q[1]} r={9} fill={RED} />
            </g>
          ))}
        </World>
      </Layer>
      <Dust f={f} n={20} />
    </Stage>
  );
};
const M3 = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.3]} pan={[[0, 0], [40, 0]]} tint="rgba(20,6,10,0.18)">
      <BG />
      <Layer depth={0.5}><Skyline y={1250} c="#0b1528" seed={13} f={f} /></Layer>
      <Layer depth={1}>
        <World oy={1150}><Floor x={-500} y={-300} w={1000} d={700} c="#0a101c" grid={80} /></World>
        <Beam x={540} y={420} w1={40} w2={360} h={760} c="214,40,57" op={0.3} />
        <Person at={[540, 1160]} s={1.5} phase={f * 0.22} walking />
      </Layer>
      <Layer depth={1.6}><Fog y={1450} op={0.5} /></Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
const M4 = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const photos = [[300, 760, -8], [780, 700, 6], [330, 1180, 5], [790, 1160, -6]];
  const prog = seg(f, 6, d - 6, Easing.linear);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.15, 1.0]} tint="rgba(6,10,22,0.2)">
      <Layer depth={0.3}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#0b1220" /></Layer>
      <Layer depth={1}>
        {photos.map((q, i) => <Photo key={i} x={q[0]} y={q[1]} rot={q[2]} s={1.3} hot={i === 3} />)}
        <polyline points={photos.map((q) => `${q[0]},${q[1] - 120}`).join(' ')} fill="none" stroke={RED} strokeWidth={4} strokeDasharray="2000" strokeDashoffset={2000 * (1 - prog)} />
      </Layer>
      <Dust f={f} n={20} />
    </Stage>
  );
};
const M5 = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const a = f * 4;
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.3]} tint="rgba(4,16,30,0.25)">
      <Layer depth={0.3}>
        <rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#07182b" />
        {Array.from({length: 22}).map((_, i) => <line key={'v' + i} x1={i * 60 - 100} y1={-300} x2={i * 60 - 100} y2={H + 300} stroke="rgba(120,180,255,0.1)" />)}
        {Array.from({length: 36}).map((_, i) => <line key={'h' + i} x1={-300} y1={i * 60 - 100} x2={W + 300} y2={i * 60 - 100} stroke="rgba(120,180,255,0.1)" />)}
      </Layer>
      <Layer depth={1}>
        <circle cx={540} cy={1000} r={330} fill="none" stroke="rgba(120,200,255,0.35)" strokeWidth={3} />
        <circle cx={540} cy={1000} r={200} fill="none" stroke="rgba(120,200,255,0.25)" strokeWidth={3} />
        <path d="M400,1100 Q540,880 680,1100 Z" fill="#162c46" stroke="#8fc2ff" strokeWidth={4} />
        <line x1={540} y1={1000} x2={540} y2={1160} stroke="#8fc2ff" strokeWidth={6} />
        <g transform={`rotate(${a},540,1000)`}><polygon points="540,1000 870,950 870,1050" fill="rgba(80,200,255,0.18)" /></g>
        <Doc x={220} y={1450} w={220} h={290} rot={-6} />
        <Doc x={860} y={1450} w={220} h={290} rot={7} stamp />
      </Layer>
      <Dust f={f} n={16} />
    </Stage>
  );
};
const M6 = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const k = seg(f, 0, d - 8);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.3, 1.05]} tint={`rgba(214,40,57,${0.1 + 0.05 * Math.sin(f * 0.3)})`}>
      <BG />
      <Layer depth={1}>
        <World oy={1200}><Floor x={-500} y={-300} w={1000} d={700} c="#0a101c" grid={80} /></World>
        <Beam x={540} y={420} w1={50} w2={460} h={820} op={0.42} />
        <Person at={[mix(240, 420, k), 1220]} s={1.5} coat="#070a10" tie={false} arms="front" />
        <Person at={[540, 1230]} s={1.5} arms="front" />
        <Person at={[mix(840, 660, k), 1220]} s={1.5} coat="#070a10" tie={false} arms="front" flip />
      </Layer>
      <Dust f={f} n={20} />
    </Stage>
  );
};
const M7 = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.4]} tint="rgba(10,10,24,0.2)">
      <BG />
      <Layer depth={0.5}><Skyline y={1320} c="#0a1426" seed={5} f={f} sc={1.2} /></Layer>
      <Layer depth={1}>
        {[0, 1, 2, 3].map((k) => {
          const r = (f * 5 + k * 90) % 420;
          return <circle key={k} cx={540} cy={1000} r={r} fill="none" stroke={RED} strokeWidth={5} opacity={Math.max(0, 1 - r / 420)} />;
        })}
        <Glow x={540} y={1000} r={240} c="214,40,57" op={0.3} />
        {[0, 1, 2, 3, 4].map((i) => (
          <Doc key={i} x={540 + (i - 2) * 120 + f * (i - 2) * 1.2} y={1000 - f * (2 + hash(i) * 2)} rot={f * (1 + i) * 0.5} w={110} h={150} op={Math.max(0, 1 - f / d)} />
        ))}
      </Layer>
      <Dust f={f} n={30} />
    </Stage>
  );
};
export const S5 = ({dur}: any) => {
  const cuts = [M1, M2, M3, M4, M5, M6, M7];
  return <Phases dur={dur} ov={3} firstFade={10} parts={cuts.map((C: any) => ({w: 1, r: (d: number, fi: number) => <C d={d} fi={fi} />}))} />;
};

// =============== ADEGAN 6 — METODE KOMUNIKASI RAHASIA ===============
const S6A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const p1 = interpolate(p, [0, 0.35, 0.45, 0.7], [-320, -20, -20, -330], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const p2 = interpolate(p, [0.55, 0.8, 0.86, 1], [340, 30, 30, 340], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const pk = p > 0.38 && p < 0.82;
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1, 1.3]} o={[540, 1050]} pan={[[-80, 0], [80, -20]]} tint="rgba(4,18,16,0.25)">
      <Layer depth={0.1}><Sky a="#0a1a22" b="#04080c" /></Layer>
      <Layer depth={1}>
        <World oy={1060}>
          <Floor x={-600} y={-500} w={1200} d={1000} c="#08161a" grid={90} gc="rgba(120,255,200,0.05)" />
          <Poly p={[iso(-600, 0, 1), iso(600, 0, 1), iso(600, 80, 1), iso(-600, 80, 1)]} fill="#14262b" />
          {[[-250, -160], [-120, -260], [200, -200], [330, -120], [-330, 160], [260, 230], [-60, 260]].map((q, i) => <Tree key={i} x={q[0]} y={q[1]} h={150 + hash(i) * 70} />)}
          <g transform={`translate(${iso(-120, 40, 0)[0]},${iso(-120, 40, 0)[1]})`}>
            <rect x={-4} y={-220} width={8} height={220} fill="#1a2233" />
            <Glow x={0} y={-220} r={190} op={0.4} />
            <circle cx={0} cy={-224} r={10} fill="#ffe3a6" />
          </g>
          {pk && <Box x={-20} y={50} w={26} d={26} h={22} c="#6b5a3e" />}
          <Person x={p1} y={80} phase={f * 0.3} walking={p < 0.36 || p > 0.46} flip={p > 0.45} s={1.1} />
          <Person x={p2} y={85} phase={f * 0.3} walking coat="#0c1018" flip={p2 > 31} s={1.1} op={p > 0.54 ? 1 : 0} />
        </World>
      </Layer>
      <Layer depth={1.6}><Fog y={1450} op={0.5} c="60,120,110" /></Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
const S6B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.35]} tint="rgba(20,10,8,0.2)">
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#07090f" /></Layer>
      <Layer depth={1}>
        <Glow x={540} y={1000} r={420} c="214,40,57" op={0.18} />
        <Doc x={540} y={mix(1010, 760, seg(p, 0.1, 0.7))} w={260} h={340} lines={9} rot={-3} />
        <Envelope x={540} y={1050} s={2.1} rot={mix(-8, 4, p)} open={0.1} />
      </Layer>
      <Dust f={f} n={30} />
    </Stage>
  );
};
const S6C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.3]} tint="rgba(0,20,14,0.3)">
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#050a0e" /></Layer>
      <Layer depth={1}>
        <Glow x={540} y={950} r={520} c="47,230,161" op={0.14} />
        <Monitor x={540} y={950} s={2.6} t={f * 2.2} />
        <g transform="translate(540,950)" opacity={seg(f, 20, 40)}>
          <rect x={-46} y={-20} width={92} height={80} rx={10} fill="#0b2a22" stroke="#2fe6a1" strokeWidth={5} />
          <path d="M-26,-20 L-26,-52 Q0,-86 26,-52 L26,-20" fill="none" stroke="#2fe6a1" strokeWidth={8} />
          <circle cx={0} cy={18} r={9} fill="#2fe6a1" />
        </g>
      </Layer>
      <Dust f={f} n={14} />
    </Stage>
  );
};
export const S6 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 4, r: (d: number, fi: number) => <S6A d={d} fi={fi} />}, {w: 3, r: (d: number, fi: number) => <S6B d={d} fi={fi} />}, {w: 3, r: (d: number, fi: number) => <S6C d={d} fi={fi} />}]} />
);

// =============== ADEGAN 7 — KESALAHAN YANG HAMPIR MEMBONGKAR SEMUANYA ===============
const S7A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const px = interpolate(p, [0.2, 0.9], [60, 230], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.2]} pan={[[-300, 0], [300, -30]]} tint="rgba(8,10,28,0.2)"
      overlay={<svg width={W} height={H} style={{position: 'absolute'}}><Cal x={540} y={300} s={0.7} a="1993" b="1993" t={0} /></svg>}>
      <Layer depth={0.1}><Sky /></Layer>
      <Layer depth={0.4}><Skyline y={1200} c="#0a1224" seed={51} f={f} /></Layer>
      <Layer depth={1}>
        <World oy={1100}>
          <Floor x={-700} y={-700} w={1400} d={1400} c="#090e1a" grid={80} />
          <Box x={-330} y={170} w={170} d={170} h={420} c="#2a4470" />
          <Windows x={-330} y={170} w={170} d={170} h={420} cols={4} rows={8} face="L" seed={61} lit={0.5} t={f} />
          <Windows x={-330} y={170} w={170} d={170} h={420} cols={4} rows={8} face="R" seed={62} lit={0.5} t={f} />
          <Box x={170} y={-330} w={180} d={180} h={340} c="#3a1c24" />
          <Windows x={170} y={-330} w={180} d={180} h={340} cols={4} rows={6} face="L" seed={71} lit={0.55} t={f} on="#ff5a66" />
          <Windows x={170} y={-330} w={180} d={180} h={340} cols={4} rows={6} face="R" seed={72} lit={0.55} t={f} on="#ff5a66" />
          <Person x={px} y={-130} phase={f * 0.3} walking={p < 0.9} s={1.1} />
        </World>
        {[0, 1, 2].map((k) => {
          const r = ((f * 3 + k * 40) % 120) + 10;
          return <circle key={k} cx={540 + 330} cy={1100 - 170} r={r} fill="none" stroke={RED} strokeWidth={3} opacity={Math.max(0, 1 - r / 130) * seg(p, 0.55, 0.7)} />;
        })}
      </Layer>
      <Layer depth={1.6}><Fog y={1500} op={0.45} /></Layer>
      <Dust f={f} n={22} />
    </Stage>
  );
};
const S7B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const mx = 540 + Math.sin(f * 0.05) * 140;
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.15]} bg="#04060b" tint="rgba(8,14,30,0.2)">
      <Layer depth={0}>
        <Glow x={540} y={700} r={480} c="40,90,170" op={0.2} />
        <Cal x={540} y={700} s={1.3} a="1993" b="1994" t={seg(f, 14, d - 30)} />
        {[-1, 0, 1].map((i) => <Doc key={i} x={540 + i * 170} y={1250} rot={i * 8} w={200} h={260} lines={8} stamp={i === 1} />)}
        <g transform={`translate(${mx},1250)`}>
          <circle cx={0} cy={0} r={70} fill="rgba(160,200,255,0.12)" stroke="#9fb4d6" strokeWidth={9} />
          <line x1={50} y1={50} x2={110} y2={110} stroke="#9fb4d6" strokeWidth={14} strokeLinecap="round" />
        </g>
      </Layer>
      <Dust f={f} n={24} />
    </Stage>
  );
};
const S7C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const ph: any[] = [[220, 620], [540, 560], [860, 640], [250, 1000], [560, 940], [840, 1020]];
  const links = [[0, 1], [1, 2], [0, 3], [1, 4], [2, 5], [3, 4], [4, 5]];
  const pr = seg(f, 10, d - 20, Easing.linear);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.25]} o={[540, 850]} tint="rgba(8,12,26,0.25)">
      <Layer depth={0.3}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#0d1626" /></Layer>
      <Layer depth={1}>
        {links.map((l, i) => {
          const a = ph[l[0]], b = ph[l[1]];
          const k = Math.max(0, Math.min(1, pr * links.length - i));
          return <line key={i} x1={a[0]} y1={a[1] - 100} x2={a[0] + (b[0] - a[0]) * k} y2={a[1] - 100 + (b[1] - a[1]) * k} stroke={RED} strokeWidth={4} />;
        })}
        {ph.map((q, i) => <Photo key={i} x={q[0]} y={q[1]} rot={(i % 2 ? 1 : -1) * 3} s={0.95} hot={i === 4 && pr > 0.8} />)}
        <Person at={[220, 1500]} s={1.7} coat="#0a0e16" />
        <Doc x={330} y={1380} w={110} h={150} rot={12} />
        <Beam x={540} y={300} w1={80} w2={900} h={1100} op={0.2 + 0.05 * Math.sin(f * 0.3)} c="200,220,255" />
      </Layer>
      <Dust f={f} n={22} />
    </Stage>
  );
};
export const S7 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 3.2, r: (d: number, fi: number) => <S7A d={d} fi={fi} />}, {w: 2.6, r: (d: number, fi: number) => <S7B d={d} fi={fi} />}, {w: 3.6, r: (d: number, fi: number) => <S7C d={d} fi={fi} />}]} />
);

// =============== ADEGAN 8 — PERANGKAP FBI ===============
const S8A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const drop = seg(f, 6, 30, Easing.out(Easing.cubic));
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.4]} o={[540, 1000]} tint="rgba(8,12,26,0.2)">
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#0a111e" /></Layer>
      <Layer depth={0.6}>
        <Photo x={540} y={640} s={1.5} />
        <line x1={540} y1={540} x2={540} y2={300} stroke={RED} strokeWidth={3} />
      </Layer>
      <Layer depth={1}>
        <World oy={1220}>
          <Box x={-300} y={-200} w={600} d={400} h={90} c="#1b2335" />
          <FlatDoc x={-80} y={-60} z={mix(500, 90, drop)} w={150} d={200} stamp />
        </World>
        <Beam x={540} y={260} w1={60} w2={760} h={960} op={0.32} />
      </Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
const S8B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.4, 1.0]} o={[540, 900]} pan={[[0, 120], [0, 0]]} tint="rgba(5,12,30,0.25)">
      <Layer depth={0.1}><Sky /></Layer>
      <Layer depth={0.4}><Skyline y={1250} c="#0b1528" seed={81} f={f} /></Layer>
      <Layer depth={1}>
        <World><Floor x={-520} y={-420} w={1000} d={900} c="#0b1220" grid={70} /><FBIBuilding t={f} hi={false} seed={9} /></World>
        <Beam x={540} y={380} w1={20} w2={240} h={700} rot={-18 + Math.sin(f * 0.04) * 14} c="200,220,255" op={0.25} />
      </Layer>
      <Layer depth={1.6}><Fog y={1500} op={0.5} /></Layer>
      <Dust f={f} n={22} />
    </Stage>
  );
};
const S8C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const cc = iso(-280, -300, 230);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.3]} o={[540, 1000]} pan={[[-40, 0], [60, -20]]} tint="rgba(6,12,28,0.2)"
      overlay={<Lower text="ERIC O'NEILL" sub="BEKERJA DI DEKAT HANSSEN" y={1260} from={Math.round(d * 0.4)} />}>
      <Layer depth={0.2}><Sky stars={false} a="#080d18" b="#04060c" /></Layer>
      <Layer depth={1}>
        <World oy={1060}>
          <Floor x={-340} y={-300} w={680} d={600} c="#0f1829" grid={60} />
          <Box x={-340} y={-330} w={680} d={30} h={320} c="#18243a" />
          <Box x={-370} y={-300} w={30} d={600} h={320} c="#141e33" />
          <Windows x={-340} y={-330} w={680} d={30} h={320} cols={6} rows={1} face="L" seed={91} lit={0.5} t={f} mx={0.2} />
          <Box x={-60} y={-240} w={200} d={90} h={75} c="#1d2a3f" />
          <Box x={-200} y={40} w={200} d={90} h={75} c="#1d2a3f" />
          <Box x={-120} y={50} z={75} w={26} d={14} h={6} c="#2b3446" />
        </World>
        <CCTV x={cc[0] + 540} y={cc[1] + 1060} s={0.8} f={f} rot={10} />
        <Beam x={cc[0] + 540 + 40} y={cc[1] + 1060 + 10} w1={20} w2={400} h={520} c="214,40,57" op={0.12} rot={-25} />
        <World oy={1060}>
          <Person x={30} y={-180} s={1.0} coat="#0b0f18" />
          <Person x={-100} y={20} s={1.05} coat="#1b3a63" phase={f * 0.35} />
        </World>
      </Layer>
      <Layer depth={1.4}><Fog y={1400} op={0.4} /></Layer>
      <Dust f={f} n={24} />
    </Stage>
  );
};
const S8D = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const lock = seg(f, 16, d - 10);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.5]} o={[540, 940]} tint="rgba(0,16,14,0.3)">
      <Layer depth={0.2}><rect x={-300} y={-300} width={W + 600} height={H + 600} fill="#040709" /></Layer>
      <Layer depth={1}>
        <Monitor x={540} y={940} s={2.7} mode="feed">
          <rect x={-156} y={20} width={312} height={86} fill="#0c1626" />
          <rect x={-110} y={-10} width={90} height={34} fill="#1d2a3f" />
          <rect x={30} y={-10} width={90} height={34} fill="#1d2a3f" />
          <circle cx={75} cy={-34} r={9} fill="#566074" />
          <rect x={64} y={-26} width={22} height={34} rx={6} fill="#0b0f18" />
          <circle cx={-65} cy={-34} r={9} fill="#566074" />
          <rect x={-76} y={-26} width={22} height={34} rx={6} fill="#1b3a63" />
          <g stroke={RED} strokeWidth={3} fill="none" opacity={lock}>
            <rect x={mix(-150, 50, lock)} y={mix(-100, -52, lock)} width={mix(300, 52, lock)} height={mix(200, 70, lock)} />
          </g>
          <circle cx={-136} cy={-88} r={5} fill={RED} opacity={Math.sin(f * 0.25) > 0 ? 1 : 0.2} />
          <text x={-124} y={-83} fontFamily="monospace" fontSize={13} fill="#d8e4ff">REC</text>
        </Monitor>
      </Layer>
      <Dust f={f} n={14} />
    </Stage>
  );
};
export const S8 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 3, r: (d: number, fi: number) => <S8A d={d} fi={fi} />}, {w: 2.4, r: (d: number, fi: number) => <S8B d={d} fi={fi} />}, {w: 3.6, r: (d: number, fi: number) => <S8C d={d} fi={fi} />}, {w: 3, r: (d: number, fi: number) => <S8D d={d} fi={fi} />}]} />
);
