import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {
  Beam, Box, Cal, CCTV, Doc, Dust, Envelope, Flag, Floor, Fog, FBIBuilding, FlatDoc, Glow, Hand, Layer, Lower,
  Monitor, Pawn, Person, Phases, Poly, RED, Skyline, Sky, Stage, Tree, W, H, Windows, World, hash, iso, lin, mix, seg,
} from './lib';

// =============== ADEGAN 1 — HOOK ===============
const S1A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1, 2.1]} o={[453, 750]} pan={[[0, 0], [-41, -100]]} tint="rgba(5,12,30,0.25)">
      <Layer depth={0.1}><Sky /></Layer>
      <Layer depth={0.3}><Skyline y={1180} c="#0a1426" seed={2} f={f} /></Layer>
      <Layer depth={0.6}><Skyline y={1280} c="#0c1a30" seed={9} f={f} sc={1.3} /></Layer>
      <Layer depth={1}>
        <World>
          <Floor x={-520} y={-420} w={1000} d={900} c="#0b1220" grid={70} />
          <FBIBuilding t={f} />
        </World>
      </Layer>
      <Layer depth={1.6}><Fog y={1500} op={0.5} /></Layer>
      <Dust f={f} n={30} />
    </Stage>
  );
};
const S1B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const sides = [-150, -90, -30, 30, 90, 150];
  const pieces: any[] = [
    ...sides.map((x) => ({x, y: -140, c: '#2f5fb0'})),
    ...sides.map((x) => ({x, y: 140, c: '#a8202b'})),
    {x: 0, y: 0, c: '#cfd6e2', king: true},
  ].sort((a, b) => a.x + a.y - (b.x + b.y));
  const k = iso(0, 0, 16);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.6, 1.0]} o={[540, 1050]} pan={[[60, 0], [-40, 0]]} tint="rgba(8,12,28,0.2)">
      <Layer depth={0.2}><Sky a="#101a33" b="#04060c" /></Layer>
      <Layer depth={0.5}>
        <Flag x={120} y={420} kind="us" f={f} op={0.45} />
        <Flag x={800} y={380} kind="su" f={f} op={0.45} />
      </Layer>
      <Layer depth={1}>
        <World oy={1080}>
          <Floor x={-500} y={-500} w={1000} d={1000} c="#080d18" grid={80} />
          <Box x={-200} y={-200} w={400} d={400} h={16} c="#1b2433" />
          {Array.from({length: 64}).map((_, n) => {
            const i = n % 8, j = Math.floor(n / 8);
            return (
              <Poly key={n} p={[iso(-200 + i * 50, -200 + j * 50, 16), iso(-150 + i * 50, -200 + j * 50, 16), iso(-150 + i * 50, -150 + j * 50, 16), iso(-200 + i * 50, -150 + j * 50, 16)]}
                fill={(i + j) % 2 ? '#d7dce6' : '#1c2432'} op={0.85} />
            );
          })}
          <Glow x={k[0]} y={k[1]} r={150} c="214,40,57" op={0.35 + 0.15 * Math.sin(f * 0.12)} />
          {pieces.map((p, i) => <Pawn key={i} x={p.x} y={p.y} c={p.c} king={p.king} />)}
        </World>
      </Layer>
      <Layer depth={1.5}><Fog y={1450} op={0.4} /></Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
export const S1 = ({dur}: any) => (
  <Phases dur={dur} firstFade={24} parts={[{w: 5, r: (d: number, fi: number) => <S1A d={d} fi={fi} />}, {w: 4, r: (d: number, fi: number) => <S1B d={d} fi={fi} />}]} />
);

// =============== ADEGAN 2 — IDENTITAS RAHASIA ===============
const S2A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const x = interpolate(p, [0, 1], [-420, 200], {easing: Easing.inOut(Easing.sin)});
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1, 1.25]} o={[540, 1050]} pan={[[-381, -200], [156, 110]]} tint="rgba(6,14,34,0.2)">
      <Layer depth={0.2}><Sky stars={false} a="#070b14" b="#05080f" /></Layer>
      <Layer depth={1}>
        <World oy={1050}>
          <Floor x={-900} y={-60} w={1800} d={220} c="#101a2c" grid={90} />
          {Array.from({length: 10}).map((_, k) => {
            const c = iso(-800 + k * 200, 30, 0);
            return <ellipse key={k} cx={c[0]} cy={c[1]} rx={110} ry={42} fill="rgba(255,210,140,0.10)" />;
          })}
          <Box x={-900} y={-120} w={1800} d={60} h={340} c="#18243a" />
          <Windows x={-900} y={-120} w={1800} d={60} h={340} cols={14} rows={1} face="L" seed={4} lit={0.4} t={f} mx={0.2} />
          <g transform={`translate(${iso(-250, -60, 0)[0]},${iso(-250, -60, 0)[1] - 280})`}><Flag x={0} y={0} kind="us" w={110} h={70} f={f} op={0.4} /></g>
          <g transform={`translate(${iso(150, -60, 0)[0]},${iso(150, -60, 0)[1] - 280})`}><Flag x={0} y={0} kind="su" w={110} h={70} f={f} op={0.4} /></g>
          <Person x={x} y={30} phase={f * 0.3} walking s={1.1} />
        </World>
      </Layer>
      <Layer depth={1.8}>
        <rect x={-90} y={-300} width={160} height={H + 600} fill="#03050a" opacity={0.92} />
        <rect x={W - 70} y={-300} width={160} height={H + 600} fill="#03050a" opacity={0.92} />
      </Layer>
      <Dust f={f} n={20} />
    </Stage>
  );
};
const S2B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.5, 1.0]} o={[540, 1000]} pan={[[0, 40], [0, -20]]} tint="rgba(6,14,34,0.2)"
      overlay={<Lower text="ROBERT HANSSEN" sub="AGEN FBI" y={1250} from={Math.round(d * 0.35)} />}>
      <Layer depth={0.2}><Sky stars={false} a="#080d18" b="#04060c" /></Layer>
      <Layer depth={1}>
        <World oy={1020}>
          <Floor x={-300} y={-300} w={600} d={600} c="#0f1829" grid={60} />
          <Box x={-300} y={-330} w={600} d={30} h={320} c="#18243a" />
          <Box x={-330} y={-300} w={30} d={600} h={320} c="#141e33" />
          <Windows x={-300} y={-330} w={600} d={30} h={320} cols={5} rows={1} face="L" seed={11} lit={0.5} t={f} mx={0.2} />
          <Windows x={-330} y={-300} w={30} d={600} h={320} cols={5} rows={1} face="R" seed={12} lit={0.4} t={f} mx={0.2} />
          <g transform={`translate(${iso(-100, -300, 0)[0]},${iso(-100, -300, 0)[1] - 280})`}><Flag x={0} y={0} kind="us" w={100} h={64} f={f} op={0.5} /></g>
          <g transform={`translate(${iso(-300, 40, 0)[0]},${iso(-300, 40, 0)[1] - 280})`}><Flag x={0} y={0} kind="su" w={100} h={64} f={f} op={0.5} /></g>
          <Box x={-120} y={-200} w={240} d={90} h={75} c="#1d2a3f" />
        </World>
        <Beam x={540} y={470} w1={50} w2={300} h={560} op={0.32} />
        <World oy={1020}><Person x={0} y={20} s={1.15} /></World>
      </Layer>
      <Layer depth={1.4}><Fog y={1400} op={0.45} /></Layer>
      <Dust f={f} n={26} />
    </Stage>
  );
};
export const S2 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 6, r: (d: number, fi: number) => <S2A d={d} fi={fi} />}, {w: 4, r: (d: number, fi: number) => <S2B d={d} fi={fi} />}]} />
);

// =============== ADEGAN 3 — AWAL MULA PENGKHIANATAN ===============
const S3A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const x = interpolate(p, [0, 0.85], [-360, -10], {extrapolateRight: 'clamp'});
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1, 1.35]} o={[410, 1025]} pan={[[0, 0], [-60, -40]]} tint="rgba(5,12,30,0.2)"
      overlay={<svg width={W} height={H} style={{position: 'absolute'}}><Cal x={540} y={330} s={0.75} a="1976" b="1976" t={0} /></svg>}>
      <Layer depth={0.1}><Sky /></Layer>
      <Layer depth={0.4}><Skyline y={1250} c="#0b1528" seed={6} f={f} /></Layer>
      <Layer depth={1}>
        <World>
          <Floor x={-500} y={-400} w={1000} d={900} c="#0b1220" grid={70} />
          <Box x={-200} y={-150} w={400} d={300} h={380} c="#26324c" />
          <Windows x={-200} y={-150} w={400} d={300} h={380} cols={6} rows={5} face="L" seed={5} lit={0.3} t={f} />
          <Windows x={-200} y={-150} w={400} d={300} h={380} cols={5} rows={5} face="R" seed={8} lit={0.3} t={f} />
          <Glow x={iso(0, 150, 50)[0]} y={iso(0, 150, 50)[1]} r={120} op={0.3} />
          <Poly p={[iso(-30, 150, 0), iso(30, 150, 0), iso(30, 150, 110), iso(-30, 150, 110)]} fill="#06090f" />
          <Person x={x} y={185} phase={f * 0.3} walking={p < 0.85} op={1 - seg(f, d * 0.8, d * 0.95)} />
        </World>
      </Layer>
      <Layer depth={1.6}><Fog y={1500} op={0.5} /></Layer>
      <Dust f={f} n={22} />
    </Stage>
  );
};
const S3B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.15]} bg="#020306" tint="rgba(0,0,0,0)">
      <Layer depth={0}>
        <Glow x={540} y={900} r={520} c="40,90,170" op={0.25} />
        <Cal x={540} y={900} s={1.6} a="1976" b="1979" t={seg(f, 12, d - 14)} sa="" sb="NOVEMBER" />
      </Layer>
      <Dust f={f} n={30} />
    </Stage>
  );
};
const S3C = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const mv = seg(p, 0.35, 0.75);
  const dx = mix(-180, 70, mv), dz = 100 + Math.sin(mv * Math.PI) * 40;
  const hp = iso(dx + 40, -40 + 70, dz);
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.9]} o={[540, 1000]} pan={[[0, 0], [0, 20]]} tint="rgba(6,10,24,0.2)"
      overlay={<svg width={W} height={H} style={{position: 'absolute'}}><Cal x={900} y={200} s={0.4} a="1979" b="1979" t={0} /></svg>}>
      <Layer depth={0.2}><Sky stars={false} a="#0a1020" b="#04060c" /></Layer>
      <Layer depth={1}>
        <World oy={1050}>
          <Floor x={-500} y={-400} w={1000} d={800} c="#0c1322" grid={70} />
          <Box x={-300} y={-180} w={600} d={360} h={100} c="#232d40" />
          <FlatDoc x={-180} y={-40} z={100} stamp />
          <FlatDoc x={-176} y={-36} z={106} />
          <FlatDoc x={-172} y={-32} z={112} stamp />
          <FlatDoc x={60} y={-40} z={100} />
          <FlatDoc x={dx} y={-40} z={dz} stamp rot={mv * 6} />
          <Box x={180} y={-150} z={100} w={36} d={36} h={10} c="#10151f" />
        </World>
        <Beam x={iso(200, -130, 0)[0] + 540} y={1050 - 280} w1={30} w2={520} h={420} op={0.4} />
        <Hand x={hp[0] + 540 + 60} y={hp[1] + 1050 + 20} rot={-18} s={1.1} />
      </Layer>
      <Dust f={f} n={30} />
    </Stage>
  );
};
export const S3 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 4, r: (d: number, fi: number) => <S3A d={d} fi={fi} />}, {w: 1.6, r: (d: number, fi: number) => <S3B d={d} fi={fi} />}, {w: 4.2, r: (d: number, fi: number) => <S3C d={d} fi={fi} />}]} />
);

// =============== ADEGAN 4 — KONTAK DENGAN KGB ===============
const S4A = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const envY = mix(700, 1060, seg(p, 0, 0.14, Easing.out(Easing.cubic)));
  const write = seg(p, 0.16, 0.52, Easing.linear);
  const into = seg(p, 0.56, 0.82);
  const hx = mix(380, 500, write) + Math.sin(f * 0.5) * 6;
  const hy = 980 + write * 90 + Math.cos(f * 0.7) * 4;
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.1, 1.6]} o={[560, 1020]} pan={[[0, 0], [20, 10]]} tint="rgba(20,8,6,0.25)" vig={0.85}>
      <Layer depth={0.2}><rect x={-400} y={-400} width={W + 800} height={H + 800} fill="#06080d" /></Layer>
      <Layer depth={1}>
        <World oy={1100}>
          <Floor x={-500} y={-400} w={1000} d={900} c="#07090f" />
          <Box x={-340} y={-200} w={680} d={400} h={110} c="#3b2a20" />
        </World>
        <Beam x={540} y={420} w1={60} w2={700} h={820} op={0.38} />
        <Doc x={mix(400, 690, into)} y={mix(1010, 1020, into)} rot={mix(-10, 0, into)} s={mix(1, 0.55, into)} w={200} h={260} op={1 - seg(p, 0.78, 0.86)} prog={write} lines={8} />
        <Envelope x={720} y={envY} s={1.1} open={1 - into} seal={p > 0.88} rot={4} />
        {p > 0.14 && p < 0.58 && <Hand x={hx} y={hy} rot={-12} s={0.9} />}
      </Layer>
      <Dust f={f} n={34} />
    </Stage>
  );
};
const S4B = ({d, fi}: any) => {
  const f = useCurrentFrame();
  const p = f / d;
  const A = [-380, 760], B = [300, 360], C = [440, 760];
  const u = seg(p, 0.1, 0.92, Easing.inOut(Easing.sin));
  const qx = (1 - u) * (1 - u) * A[0] + 2 * (1 - u) * u * B[0] + u * u * C[0];
  const qy = (1 - u) * (1 - u) * A[1] + 2 * (1 - u) * u * B[1] + u * u * C[1];
  return (
    <Stage dur={d} fadeIn={fi} zoom={[1.0, 1.2]} pan={[[-300, 0], [300, -30]]} tint="rgba(8,10,28,0.2)">
      <Layer depth={0.1}><Sky a="#0c1228" b="#05060c" /></Layer>
      <Layer depth={0.4}><Skyline y={1180} c="#0a1224" seed={21} f={f} /></Layer>
      <Layer depth={1}>
        <World oy={1100}>
          <Floor x={-700} y={-700} w={1400} d={1400} c="#090e1a" grid={80} />
          <g>
            <Box x={-330} y={170} w={160} d={160} h={300} c="#2a4470" />
            <Windows x={-330} y={170} w={160} d={160} h={300} cols={4} rows={6} face="L" seed={31} lit={0.5} t={f} />
            <Windows x={-330} y={170} w={160} d={160} h={300} cols={4} rows={6} face="R" seed={32} lit={0.5} t={f} />
          </g>
          <g>
            <Box x={170} y={-330} w={180} d={180} h={440} c="#3a1c24" />
            <Windows x={170} y={-330} w={180} d={180} h={440} cols={4} rows={8} face="L" seed={41} lit={0.55} t={f} on="#ff5a66" />
            <Windows x={170} y={-330} w={180} d={180} h={440} cols={4} rows={8} face="R" seed={42} lit={0.55} t={f} on="#ff5a66" />
            <circle cx={iso(260, -240, 440)[0]} cy={iso(260, -240, 440)[1] - 20} r={7} fill={RED} opacity={Math.sin(f * 0.2) > 0 ? 1 : 0.3} />
          </g>
          <Glow x={iso(260, -240, 200)[0]} y={iso(260, -240, 200)[1]} r={260} c="214,40,57" op={0.22} />
        </World>
        <path d={`M${A[0] + 540},${A[1] + 600} Q${B[0] + 540},${B[1] + 600} ${C[0] + 540},${C[1] + 600}`} stroke="#8fb2ff" strokeOpacity={0.5} strokeWidth={3} strokeDasharray="10 12" fill="none" />
        <Envelope x={qx + 540} y={qy + 600} s={0.4} rot={mix(-20, 20, u)} seal />
      </Layer>
      <Layer depth={1.6}><Fog y={1500} op={0.45} /></Layer>
      <Dust f={f} n={22} />
    </Stage>
  );
};
export const S4 = ({dur}: any) => (
  <Phases dur={dur} firstFade={10} parts={[{w: 6, r: (d: number, fi: number) => <S4A d={d} fi={fi} />}, {w: 3.5, r: (d: number, fi: number) => <S4B d={d} fi={fi} />}]} />
);
