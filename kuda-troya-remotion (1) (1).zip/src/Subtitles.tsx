import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT} from './lib';

export type SubScene = {from: number; to: number; text: string};

const weight = (w: string) => w.length + (/[.!?…]$/.test(w) ? 5 : /[,;:]$/.test(w) ? 3 : 0);

// Pecah kata menjadi potongan 3-5 kata (berhenti di tanda baca bila perlu)
const chunkify = (words: string[]) => {
  const chunks: number[][] = [];
  let cur: number[] = [];
  let chars = 0;
  words.forEach((w, i) => {
    cur.push(i);
    chars += w.length + 1;
    const punct = /[.!?…,;:]$/.test(w);
    if (cur.length >= 5 || chars > 30 || (punct && cur.length >= 3)) {
      chunks.push(cur);
      cur = [];
      chars = 0;
    }
  });
  if (cur.length) {
    if (cur.length < 2 && chunks.length) chunks[chunks.length - 1].push(...cur);
    else chunks.push(cur);
  }
  return chunks;
};

export const Subtitles = ({scenes}: {scenes: SubScene[]}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sc = scenes.find((s) => f >= s.from && f < s.to);
  if (!sc) return null;
  const words = sc.text.split(/\s+/);
  const ws = words.map(weight);
  const total = ws.reduce((a, b) => a + b, 0);
  const t = (f - sc.from) / Math.max(1, sc.to - sc.from);
  let acc = 0;
  let active = words.length - 1;
  for (let i = 0; i < words.length; i++) {
    acc += ws[i];
    if (t <= acc / total) {
      active = i;
      break;
    }
  }
  const chunks = chunkify(words);
  const ci = chunks.findIndex((c) => c.includes(active));
  const chunk = chunks[ci];
  const startW = chunk[0];
  const startT = ws.slice(0, startW).reduce((a, b) => a + b, 0) / total;
  const startF = sc.from + startT * (sc.to - sc.from);
  const local = f - startF;
  const pop = spring({frame: local, fps, config: {damping: 14, stiffness: 220}, durationInFrames: 12});
  const op = interpolate(local, [0, 4], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute',
          left: 60,
          width: 840,
          top: 1370,
          height: 280,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          opacity: op,
          transform: `scale(${0.88 + 0.12 * pop}) translateY(${(1 - pop) * 16}px)`,
        }}
      >
        <div
          style={{
            fontFamily: FONT,
            fontWeight: 900,
            fontSize: 86,
            lineHeight: 1.12,
            color: '#fff',
            textTransform: 'uppercase',
            letterSpacing: 1,
            WebkitTextStroke: '12px #05070b',
            paintOrder: 'stroke fill',
            textShadow: '0 6px 18px rgba(0,0,0,0.7)',
          }}
        >
          {chunk.map((wi) => (
            <span key={wi} style={{color: wi === active ? '#ffd23f' : '#fff', marginRight: 18, display: 'inline-block'}}>
              {words[wi]}
            </span>
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};
