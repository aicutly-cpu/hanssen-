import React from 'react';
import {Composition, staticFile} from 'remotion';
import {getAudioDurationInSeconds} from '@remotion/media-utils';
import SCRIPT from './script.json';
import {LEAD, TAIL, Video} from './Video';

const FPS = 30;

export const Root = () => (
  <Composition
    id="Hanssen"
    component={Video}
    width={1080}
    height={1920}
    fps={FPS}
    durationInFrames={FPS * 100}
    defaultProps={{voDur: 100, timing: null as any, voMissing: true}}
    calculateMetadata={async () => {
      let voDur = 0;
      let voMissing = false;
      try {
        voDur = await getAudioDurationInSeconds(staticFile('vo.mp3'));
      } catch (e) {
        // vo.mp3 belum ada: pratinjau saja, perkiraan 2,4 kata/detik
        voMissing = true;
        const words = SCRIPT.map((s) => s.text.split(/\s+/).length).reduce((a, b) => a + b, 0);
        voDur = words / 2.4;
      }
      let timing: any = null;
      try {
        const r = await fetch(staticFile('timing.json'));
        if (r.ok) timing = await r.json();
      } catch (e) {}
      return {
        durationInFrames: Math.ceil((LEAD + voDur + TAIL) * FPS),
        props: {voDur, timing, voMissing},
      };
    }}
  />
);
