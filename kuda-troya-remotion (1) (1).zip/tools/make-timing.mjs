// Membuat public/timing.json dari analisis jeda (silence) pada public/vo.mp3.
// Batas adegan dipasang di jeda antarkalimat terdekat dari perkiraan berbasis jumlah karakter.
import {execSync} from 'node:child_process';
import fs from 'node:fs';

const VO = 'public/vo.mp3';
if (!fs.existsSync(VO)) {
  console.error('public/vo.mp3 tidak ditemukan. Letakkan file voice over di sana dulu.');
  process.exit(1);
}
const script = JSON.parse(fs.readFileSync('src/script.json', 'utf8'));
const dur = parseFloat(execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 "${VO}"`).toString());
const log = execSync(`ffmpeg -hide_banner -nostats -i "${VO}" -af silencedetect=noise=-32dB:d=0.28 -f null - 2>&1`, {maxBuffer: 1e8}).toString();
const starts = [...log.matchAll(/silence_start: ([\d.]+)/g)].map((m) => +m[1]);
const ends = [...log.matchAll(/silence_end: ([\d.]+)/g)].map((m) => +m[1]);
const sil = starts.map((s, i) => ({s, e: ends[i] ?? dur})).map((x) => ({...x, mid: (x.s + x.e) / 2, len: x.e - x.s}));

let t0 = 0, t1 = dur;
if (sil.length && sil[0].s < 0.15) t0 = sil[0].e;
if (sil.length && sil[sil.length - 1].e > dur - 0.15) t1 = sil[sil.length - 1].s;
const inner = sil.filter((x) => x.mid > t0 + 0.5 && x.mid < t1 - 0.5);

const w = script.map((s) => s.text.length + (s.text.match(/[.!?]/g) || []).length * 6);
const tot = w.reduce((a, b) => a + b, 0);
const bounds = [0];
let acc = 0, prev = 0;
for (let i = 0; i < script.length - 1; i++) {
  acc += w[i];
  const target = t0 + ((t1 - t0) * acc) / tot;
  let best = null, bs = -1e9;
  for (const c of inner) {
    if (c.mid <= prev + 1) continue;
    const sc = c.len * 2 - Math.abs(c.mid - target) * 0.6;
    if (Math.abs(c.mid - target) < 3 && sc > bs) { bs = sc; best = c; }
  }
  const b = best ? best.mid : target;
  bounds.push(b);
  prev = b;
}
bounds.push(dur);
const scenes = script.map((s, i) => ({id: s.id, start: +bounds[i].toFixed(3), end: +bounds[i + 1].toFixed(3)}));
fs.writeFileSync('public/timing.json', JSON.stringify({voDuration: dur, scenes}, null, 2));
console.log('Durasi VO:', dur.toFixed(2), 's');
scenes.forEach((s) => console.log(`Adegan ${s.id}: ${s.start}s - ${s.end}s`));
