import {execSync} from 'node:child_process';
import fs from 'node:fs';

if (!fs.existsSync('public/vo.mp3')) {
  console.error('Render dibatalkan: public/vo.mp3 (voice over) belum ada. Video tidak akan dirender hanya dengan musik.');
  process.exit(1);
}
if (!fs.existsSync('public/timing.json')) execSync('node tools/make-timing.mjs', {stdio: 'inherit'});
fs.mkdirSync('out', {recursive: true});
execSync('npx remotion render src/index.ts Hanssen out/kuda-troya-di-jantung-fbi.mp4 --codec=h264 --crf=18 --audio-codec=aac', {stdio: 'inherit'});
console.log('Selesai: out/kuda-troya-di-jantung-fbi.mp4');
