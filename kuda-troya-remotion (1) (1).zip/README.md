# Kuda Troya di Jantung FBI — proyek Remotion

1. `npm install`
2. Letakkan voice over di `public/vo.mp3` (musik latar sudah ada di `public/bgm.mp3`).
3. `npm run timing` (opsional, butuh ffmpeg): memasang batas adegan di jeda antarkalimat.
4. `npm start` untuk pratinjau, `npm run render` untuk menghasilkan `out/kuda-troya-di-jantung-fbi.mp4` (1080×1920, 30 FPS, H.264).

Durasi video otomatis = durasi `vo.mp3` + 0,6 dtk awal + 2,4 dtk penutup. Subtitle diambil dari `src/script.json`.
Jangan ubah isi naskah di `script.json` agar sesuai dengan rekaman.
